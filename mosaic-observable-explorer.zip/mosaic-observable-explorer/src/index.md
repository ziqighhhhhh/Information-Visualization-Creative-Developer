---
title: Market Intelligence
theme: [near-midnight, alt, wide]
toc: false
sidebar: false
header: false
footer: false
---

```js
import * as vg from "@uwdata/vgplot";
```

```js
vg.coordinator().databaseConnector(vg.wasmConnector());

function pseudo(seed) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

const marketDefs = [
  ["Asia Pacific", "Vietnam", 1.05],
  ["Asia Pacific", "Singapore", 0.82],
  ["Middle East & Africa", "Saudi Arabia", 1.18],
  ["Middle East & Africa", "Uganda", 0.56],
  ["Americas", "Brazil", 1.34],
  ["Americas", "Mexico", 0.92]
];

const productDefs = [
  ["Standard", 1.00],
  ["Premium", 1.28],
  ["Compact", 0.78]
];

const marketRows = [];

for (const year of [2024, 2025, 2026]) {
  for (let mi = 0; mi < marketDefs.length; mi++) {
    const [region, market, marketFactor] = marketDefs[mi];

    for (let pi = 0; pi < productDefs.length; pi++) {
      const [product, productFactor] = productDefs[pi];

      for (let month = 1; month <= 12; month++) {
        const season =
          1
          + 0.10 * Math.sin((month - 2) / 12 * Math.PI * 2)
          + 0.035 * Math.cos(month / 12 * Math.PI * 4);

        const noise =
          0.96
          + pseudo(year * 1000 + mi * 100 + pi * 20 + month) * 0.08;

        const revenue =
          36000
          * marketFactor
          * productFactor
          * (1 + (year - 2024) * 0.095)
          * season
          * noise;

        marketRows.push({
          t: (year - 2024) * 12 + month,
          year,
          month,
          period: `${year}-${String(month).padStart(2, "0")}`,
          region,
          market,
          product,
          revenue: Math.round(revenue),
          margin:
            18
            + 5 * productFactor
            + 2.5 * marketFactor
            + (year - 2024) * 0.7
            + (pseudo(month * 91 + mi * 17 + pi) - 0.5) * 1.4
        });
      }
    }
  }
}

await vg.coordinator().exec(
  vg.loadObjects("market", marketRows, {replace: true})
);

const $filter = vg.Selection.crossfilter();
```

<style>
:root {
  --brand: #f97316;
  --brand-soft: #fdba74;
  --hairline: color-mix(in srgb, currentColor 11%, transparent);
  --subtle: color-mix(in srgb, currentColor 52%, transparent);
}

#observablehq-main {
  max-width: none;
  padding: 0 28px 48px;
}

.hero {
  min-height: 38vh;
  display: grid;
  grid-template-columns: minmax(0, 1.35fr) minmax(280px, .65fr);
  align-items: end;
  gap: 48px;
  padding: 64px 0 40px;
  border-bottom: 1px solid var(--hairline);
}

.hero-kicker {
  margin-bottom: 18px;
  color: var(--brand);
  font-size: 11px;
  font-weight: 800;
  letter-spacing: .16em;
  text-transform: uppercase;
}

.hero h1 {
  max-width: 880px;
  margin: 0;
  font-size: clamp(52px, 7vw, 112px);
  line-height: .86;
  letter-spacing: -.065em;
  font-weight: 720;
}

.hero h1 em {
  color: var(--brand-soft);
  font-style: normal;
}

.hero-copy {
  max-width: 420px;
  padding-bottom: 6px;
  color: var(--subtle);
  font-size: 15px;
  line-height: 1.7;
}

.hero-meta {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  margin-top: 28px;
  border: 1px solid var(--hairline);
  border-radius: 16px;
  overflow: hidden;
}

.hero-stat {
  padding: 16px 18px;
  background: color-mix(in srgb, var(--theme-background-alt) 92%, transparent);
}

.hero-stat span {
  display: block;
  color: var(--subtle);
  font-size: 9px;
  letter-spacing: .1em;
  text-transform: uppercase;
}

.hero-stat strong {
  display: block;
  margin-top: 8px;
  font-size: 22px;
  letter-spacing: -.03em;
}

.section {
  padding-top: 42px;
}

.section-number {
  color: var(--brand);
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .14em;
}

.section-title {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(300px, .55fr);
  gap: 40px;
  align-items: end;
  margin: 8px 0 22px;
}

.section-title h2 {
  margin: 0;
  font-size: clamp(30px, 4vw, 58px);
  line-height: .95;
  letter-spacing: -.045em;
}

.section-title p {
  margin: 0;
  color: var(--subtle);
  font-size: 13px;
  line-height: 1.65;
}

.panel {
  border-top: 1px solid var(--hairline);
  padding-top: 18px;
}

.panel-head {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  align-items: baseline;
  margin-bottom: 12px;
}

.panel-head h3 {
  margin: 0;
  font-size: 15px;
}

.panel-head span {
  color: var(--subtle);
  font-size: 10px;
}

.brush-note {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.brush-note::before {
  content: "";
  width: 24px;
  height: 1px;
  background: var(--brand);
}

.two-col {
  display: grid;
  grid-template-columns: minmax(0, .86fr) minmax(0, 1.14fr);
  gap: 46px;
  margin-top: 34px;
}

.caption {
  margin-top: 10px;
  color: var(--subtle);
  font-size: 10px;
  line-height: 1.55;
}

.table-panel {
  margin-top: 40px;
  padding: 24px 0 0;
  border-top: 1px solid var(--hairline);
}

/* Mosaic table: deliberately restrained rather than app-like */
.mosaic-inputs-table {
  border: 1px solid var(--hairline) !important;
  border-radius: 14px !important;
  overflow: hidden !important;
  background: transparent !important;
}

.mosaic-inputs-table table {
  font-size: 11px !important;
}

.mosaic-inputs-table th {
  font-size: 9px !important;
  letter-spacing: .07em !important;
  text-transform: uppercase !important;
}

svg {
  overflow: visible;
}

@media (max-width: 900px) {
  #observablehq-main {
    padding: 0 18px 36px;
  }

  .hero,
  .section-title,
  .two-col {
    grid-template-columns: 1fr;
  }

  .hero {
    gap: 26px;
    min-height: auto;
  }

  .hero-meta {
    grid-template-columns: 1fr;
  }
}
</style>

<div class="hero">
  <div>
    <div class="hero-kicker">Market intelligence / Mosaic experiment</div>
    <h1>Explore the signal,<br><em>keep the context.</em></h1>

    <div class="hero-meta">
      <div class="hero-stat">
        <span>Markets</span>
        <strong>6</strong>
      </div>
      <div class="hero-stat">
        <span>Periods</span>
        <strong>36 mo.</strong>
      </div>
      <div class="hero-stat">
        <span>Products</span>
        <strong>3</strong>
      </div>
    </div>
  </div>

  <div class="hero-copy">
    This version stops treating interaction as a collection of custom event
    handlers. The views below share a Mosaic selection, so brushing time,
    selecting a market, and inspecting rows become one coordinated analytical
    system.
  </div>
</div>

<div class="section">
  <div class="section-number">01 / OVERVIEW + DETAIL</div>

  <div class="section-title">
    <h2>Choose a window.<br>Then read the detail.</h2>
    <p>
      Drag across the overview series. The detail chart below is filtered by
      the same selection rather than being manually re-rendered by application code.
    </p>
  </div>

  <div class="panel">
    <div class="panel-head">
      <h3>36-month overview</h3>
      <span class="brush-note">Drag to select a time interval</span>
    </div>

```js
const overview = vg.plot(
  vg.areaY(
    vg.from("market", {filterBy: $filter}),
    {
      x: "t",
      y: vg.sum("revenue"),
      fill: "#f97316",
      fillOpacity: 0.22,
      curve: "monotone-x"
    }
  ),
  vg.lineY(
    vg.from("market", {filterBy: $filter}),
    {
      x: "t",
      y: vg.sum("revenue"),
      stroke: "#fb923c",
      strokeWidth: 2,
      curve: "monotone-x"
    }
  ),
  vg.intervalX({
    as: $filter,
    brush: {
      fill: "#f97316",
      fillOpacity: 0.08,
      stroke: "#fb923c"
    }
  }),
  vg.xLabel(null),
  vg.yLabel("Revenue"),
  vg.yGrid(true),
  vg.yTickFormat("s"),
  vg.width(1120),
  vg.height(220),
  vg.margins({left: 55, right: 20, top: 10, bottom: 32})
);

display(overview);
```

    <div class="caption">
      Mosaic official interaction pattern: <strong>intervalX → shared Selection</strong>.
    </div>
  </div>

  <div class="panel" style="margin-top:28px">
    <div class="panel-head">
      <h3>Selected interval</h3>
      <span>Filtered by the brush above</span>
    </div>

```js
const detail = vg.plot(
  vg.areaY(
    vg.from("market", {filterBy: $filter}),
    {
      x: "t",
      y: vg.sum("revenue"),
      fill: "#fdba74",
      fillOpacity: 0.16,
      curve: "monotone-x"
    }
  ),
  vg.lineY(
    vg.from("market", {filterBy: $filter}),
    {
      x: "t",
      y: vg.sum("revenue"),
      stroke: "#fed7aa",
      strokeWidth: 2.4,
      curve: "monotone-x"
    }
  ),
  vg.yDomain(vg.Fixed),
  vg.xLabel(null),
  vg.yLabel("Revenue"),
  vg.yGrid(true),
  vg.yTickFormat("s"),
  vg.width(1120),
  vg.height(310),
  vg.margins({left: 55, right: 20, top: 12, bottom: 35})
);

display(detail);
```
  </div>
</div>

<div class="section">
  <div class="section-number">02 / CROSS-FILTER</div>

  <div class="section-title">
    <h2>Select one market.<br>Everything else responds.</h2>
    <p>
      The ranking and product mix are Mosaic clients sharing the same
      cross-filter selection. Click a market bar to isolate it; the time-series,
      mix, and table update through the coordinator.
    </p>
  </div>

  <div class="two-col">
    <div class="panel">
      <div class="panel-head">
        <h3>Market ranking</h3>
        <span>Click / shift-click</span>
      </div>

```js
const ranking = vg.plot(
  vg.barX(
    vg.from("market", {filterBy: $filter}),
    {
      x: vg.sum("revenue"),
      y: "market",
      fill: "#f97316",
      fillOpacity: 0.86,
      sort: {y: "-x"}
    }
  ),
  vg.toggleY({as: $filter}),
  vg.highlight({
    by: $filter,
    channels: {opacity: 0.14}
  }),
  vg.xLabel("Revenue"),
  vg.yLabel(null),
  vg.xTickFormat("s"),
  vg.yDomain(vg.Fixed),
  vg.width(510),
  vg.height(330),
  vg.marginLeft(100),
  vg.marginRight(20)
);

display(ranking);
```
    </div>

    <div class="panel">
      <div class="panel-head">
        <h3>Product mix</h3>
        <span>Same selection, different question</span>
      </div>

```js
const mix = vg.plot(
  vg.barY(
    vg.from("market", {filterBy: $filter}),
    {
      x: "product",
      y: vg.sum("revenue"),
      fill: "product",
      fillOpacity: 0.84,
      sort: {x: "-y"}
    }
  ),
  vg.colorScheme("warm"),
  vg.yLabel("Revenue"),
  vg.xLabel(null),
  vg.yTickFormat("s"),
  vg.width(610),
  vg.height(330),
  vg.marginLeft(55),
  vg.marginRight(20)
);

display(mix);
```
    </div>
  </div>
</div>

<div class="section">
  <div class="section-number">03 / DATA, NOT DECORATION</div>

  <div class="section-title">
    <h2>The table is part of<br>the same analytical system.</h2>
    <p>
      This is Mosaic’s own sortable, incremental table client. It is not a
      hand-built HTML table and it receives the same filter selection as the charts.
    </p>
  </div>

  <div class="table-panel">

```js
const table = vg.table({
  from: "market",
  filterBy: $filter,
  columns: [
    "period",
    "region",
    "market",
    "product",
    "revenue",
    "margin"
  ],
  align: {
    revenue: "right",
    margin: "right"
  },
  format: {
    revenue: value => `$${Number(value).toLocaleString()}`,
    margin: value => `${Number(value).toFixed(1)}%`
  },
  width: {
    period: 100,
    region: 180,
    market: 150,
    product: 120,
    revenue: 130,
    margin: 100
  },
  height: 330
});

display(table);
```

  </div>
</div>
