# Mosaic + Observable Framework Explorer

This is a deliberately different implementation from the earlier ECharts/Tabulator prototypes.

It uses:

- Observable Framework 1.13.4 for page structure, theme, responsive dashboard shell, and build system.
- UW Mosaic / vgplot 0.31.0 for coordinated views.
- DuckDB-WASM through Mosaic's `wasmConnector`.
- Mosaic `Selection.crossfilter()` as the shared interaction state.
- Mosaic's own sortable table client.

## Why this version

The previous prototypes used chart and table libraries as isolated parts and then hand-wired the interaction and page design.

This project moves both interaction semantics and much of the visual grammar into mature open-source systems.

The key interaction patterns come directly from Mosaic's documented APIs:

- `intervalX({as: selection})` for overview/detail brushing.
- `toggleY({as: selection})` for market selection.
- `highlight({by: selection})` for focus/context deemphasis.
- `from(table, {filterBy: selection})` for linked filtering.
- `table({from, filterBy})` for a sortable linked table.

## Run locally

Requires Node.js.

```bash
npm install
npm run dev
```

Observable Framework will print the local preview URL (normally http://localhost:3000).

## Build

```bash
npm run build
```

The generated static site is written to `dist/`.

## Important

This is a Framework project, not a single-file HTML demo. That is intentional: Mosaic uses DuckDB-WASM and is better treated as an application runtime rather than forced into a fragile `file://` HTML preview.
