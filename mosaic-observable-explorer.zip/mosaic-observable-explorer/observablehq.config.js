export default {
  title: "Market Intelligence",
  root: "src",
  theme: ["near-midnight", "alt", "wide"],
  toc: false,
  sidebar: false,
  header: false,
  footer: false
};
